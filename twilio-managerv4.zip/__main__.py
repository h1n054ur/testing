"""
Enables 'python -m twilio-manager' entrypoint.
"""
print("Twilio Manager CLI - Module Entry (skeleton)")
